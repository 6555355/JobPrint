#ifndef __ParserDefine__H__
#define __ParserDefine__H__

typedef double			FLOAT64;

#endif
